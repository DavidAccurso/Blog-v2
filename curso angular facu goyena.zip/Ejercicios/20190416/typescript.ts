import { Persona } from './Persona';

export class P implements Persona {
    private nombre: string = '';
    private apellido: string = '';

    public saludar(): void
    {
        alert('hola!');
    }
}