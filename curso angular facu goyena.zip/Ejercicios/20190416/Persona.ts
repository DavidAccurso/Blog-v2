export interface IPersona {
    nombre: string;
    apellido?: string;
}