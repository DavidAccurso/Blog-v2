"use strict";
exports.__esModule = true;
var P = /** @class */ (function () {
    function P() {
        this.nombre = '';
        this.apellido = '';
    }
    P.prototype.saludar = function () {
        alert('hola!');
    };
    return P;
}());
exports.P = P;
