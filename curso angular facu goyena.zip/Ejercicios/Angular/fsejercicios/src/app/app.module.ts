import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MiSegundoComponent } from './mi-segundo/mi-segundo.component';
import { AutoresComponent } from './autores/autores.component';
import { HomeComponent } from './home/home.component';
import { EmptyComponent } from './empty/empty.component';
import { PersonService } from './services/person.service';

@NgModule({
  declarations: [
    AppComponent,
    MiSegundoComponent,
    AutoresComponent,
    HomeComponent,
    EmptyComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [
    PersonService
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
