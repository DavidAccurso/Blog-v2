import { Injectable } from '@angular/core';

@Injectable()
export class PersonService {

    public nombre: string = 'Facundo';
}