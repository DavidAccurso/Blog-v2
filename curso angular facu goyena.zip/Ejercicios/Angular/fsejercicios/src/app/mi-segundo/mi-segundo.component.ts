import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mi-segundo',
  templateUrl: './mi-segundo.component.html',
  styleUrls: ['./mi-segundo.component.scss']
})
export class MiSegundoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
