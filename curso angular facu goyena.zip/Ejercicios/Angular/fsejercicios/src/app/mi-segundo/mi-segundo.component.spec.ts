import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiSegundoComponent } from './mi-segundo.component';

describe('MiSegundoComponent', () => {
  let component: MiSegundoComponent;
  let fixture: ComponentFixture<MiSegundoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiSegundoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiSegundoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
