import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public title: string = 'fsejercicios';

  public ngOnInit(): void {
    setTimeout(() => {
      this.title = 'hola :D';
    }, 5000);
  }
}
